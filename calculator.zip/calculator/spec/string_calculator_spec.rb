require './lib/string_calculator.rb'

describe StringCalculator do
  
   let(:calc) { StringCalculator.new }

	context "A string of comma-separated numbers given" do
		it "should add the given numbers" do
			sum = calc.add("2,3")
			expect(sum).to eql(5)
		end
		
		it "should accept n numbers of params" do
		  #add_method = StringCalculator.instance_method(:add)
                  #puts add_method.parameters.length
		  #expect(add_method.parameters.flatten[:numbers].length).to eq(2)
		  
		end

		it "should handle new lines between numbers" do
      		  sum = calc.add("1,2\n3\n4")
		  expect(sum).to eql(10)		  
		end

 		it "should accept custom delimeter" do
		  sum = calc.add("//;\n1;2")
		  expect(sum).to eql(3)
		end
	end
end
