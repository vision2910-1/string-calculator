class StringCalculator

 def add(*numbers)
   # Split the arguments on the basis of new line & commas
   # numbers = numbers.first.split(/\n|,/)
  
   input_str = numbers.first
   
   
   int_arr = input_str.split(/#{delimeter(input_str)}/).reject { |e| e.to_i == 0 }
   
   return int_arr.map(&:to_i).sum
  end

private

 def delimeter(input_str)
   delim = "\n | "
   delim += if input_str.include?('//')
              input_str.string[2]
            else
              ","
            end
 end
end
